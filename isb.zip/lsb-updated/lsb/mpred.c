#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
typedef struct
{
    long size;
    char filename[256];
} FileInfo;
void findMaxFileSize(const char *directory)
{
    DIR *dir;
    struct dirent *entry;
    FileInfo maxFile = {.size = 0};
    if ((dir = opendir(directory)) == NULL)
    {
        perror("opendir");
        return;
    }
    while ((entry = readdir(dir)) != NULL)
    {
        if (entry->d_type == DT_REG)
        { // Regular file
            char filepath[1024];
            snprintf(filepath, sizeof(filepath), "%s/%s", directory, entry->d_name);
            struct stat fileStat;
            if (stat(filepath, &fileStat) == 0)
            {
                long size = fileStat.st_size; // Get the size of the file
                if (size > maxFile.size)
                {
                    maxFile.size = size;
                    strncpy(maxFile.filename, entry->d_name,
                            sizeof(maxFile.filename) - 1);
                }
            }
        }
    }
    closedir(dir);
    if (maxFile.size > 0)
    {
        printf("File: %s, Max File Size: %ld bytes\n", maxFile.filename,
               maxFile.size);
    }
    else
    {
        printf("No files found in the directory.\n");
    }
}
int main()
{
    char *currentDir = ".";
    findMaxFileSize(currentDir);
    return;
}