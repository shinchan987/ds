#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PROCESSES 5
#define MAX_EVENTS 10

// Function to display a vector clock
void display_vector_clock(int vc[], int n) {
    printf("[");
    for (int i = 0; i < n; i++) {
        printf("%d", vc[i]);
        if (i < n - 1) {
            printf(", ");
        }
    }
    printf("]\n");
}

// Lamport Logical Clock Simulation
void lamport_logical_clock() {
    int logical_clock[MAX_PROCESSES] = {0};
    int num_processes;

    printf("Enter the number of processes: ");
    scanf("%d", &num_processes);

    int event_matrix[MAX_PROCESSES][MAX_EVENTS];
    printf("Enter the event matrix (%d x %d) (use -1 for no event):\n", num_processes, MAX_EVENTS);
    for (int i = 0; i < num_processes; i++) {
        for (int j = 0; j < MAX_EVENTS; j++) {
            scanf("%d", &event_matrix[i][j]);
        }
    }

    printf("\nSimulating Lamport Logical Clock:\n");
    for (int i = 0; i < num_processes; i++) {
        printf("Process %d: ", i);
        for (int j = 0; j < MAX_EVENTS && event_matrix[i][j] != -1; j++) {
            logical_clock[i]++;
            if (event_matrix[i][j] != 0) {
                int sender = event_matrix[i][j] - 1;
                if (logical_clock[i] <= logical_clock[sender]) {
                    logical_clock[i] = logical_clock[sender] + 1;
                }
            }
            printf("%d ", logical_clock[i]);
        }
        printf("\n");
    }
}

// Vector Clock Simulation
void vector_clock_simulation() {
    int vector_clocks[MAX_PROCESSES][MAX_PROCESSES] = {0};
    int num_processes, num_events;

    printf("\nEnter the number of processes: ");
    scanf("%d", &num_processes);
    printf("Enter the number of events per process: ");
    scanf("%d", &num_events);

    printf("\nSimulating Vector Clock:\n");
    for (int i = 0; i < num_processes; i++) {
        printf("Process %d:\n", i);
        for (int j = 0; j < num_events; j++) {
            // Local event
            vector_clocks[i][i]++;

            // Display vector clock
            printf("Event %d: ", j + 1);
            display_vector_clock(vector_clocks[i], num_processes);

            // Simulate message send/receive
            if (j % 2 == 0 && i < num_processes - 1) {
                int receiver = i + 1;
                printf("Message sent from Process %d to Process %d\n", i, receiver);
                for (int k = 0; k < num_processes; k++) {
                    if (vector_clocks[i][k] > vector_clocks[receiver][k]) {
                        vector_clocks[receiver][k] = vector_clocks[i][k];
                    }
                }
                vector_clocks[receiver][receiver]++;
                printf("Updated clock for Process %d: ", receiver);
                display_vector_clock(vector_clocks[receiver], num_processes);
            }
        }
    }
}

int main() {
    printf("Choose the clock synchronization method:\n");
    printf("1. Lamport Logical Clock\n");
    printf("2. Vector Clock\n");
    printf("Enter your choice: ");

    int choice;
    scanf("%d", &choice);

    switch (choice) {
        case 1:
            lamport_logical_clock();
            break;
        case 2:
            vector_clock_simulation();
            break;
        default:
            printf("Invalid choice!\n");
    }

    return 0;
}
