#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>

// Define server addresses and ports
#define SERVER1_IP "127.0.0.1"
#define SERVER1_PORT 8001
#define SERVER2_IP "127.0.0.1"
#define SERVER2_PORT 8002

#define LB_PORT 9000
#define BUFFER_SIZE 1024

// Function to simulate CPU utilization (returns a random value for simplicity)
int get_cpu_utilization(const char* server_ip, int server_port) {
    // In a real scenario, you'd query the server for its CPU usage
    return rand() % 100; // Simulated CPU utilization (0 to 99)
}

// Function to connect to a server and send/receive data
void communicate_with_server(const char* server_ip, int server_port, const char* input, char* output) {
    int sock;
    struct sockaddr_in server_addr;

    // Create socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Configure server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(server_port);
    inet_pton(AF_INET, server_ip, &server_addr.sin_addr);

    // Connect to the server
    if (connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection to server failed");
        close(sock);
        exit(EXIT_FAILURE);
    }

    // Send data to server
    send(sock, input, strlen(input), 0);

    // Receive data from server
    recv(sock, output, BUFFER_SIZE, 0);

    // Close the socket
    close(sock);
}

int main() {
    int lb_sock, client_sock;
    struct sockaddr_in lb_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
    char buffer[BUFFER_SIZE], response[BUFFER_SIZE];

    // Seed random number generator
    srand(time(NULL));

    // Create load balancer socket
    if ((lb_sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Load balancer socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Configure load balancer address
    lb_addr.sin_family = AF_INET;
    lb_addr.sin_addr.s_addr = INADDR_ANY;
    lb_addr.sin_port = htons(LB_PORT);

    // Bind load balancer socket
    if (bind(lb_sock, (struct sockaddr*)&lb_addr, sizeof(lb_addr)) < 0) {
        perror("Load balancer bind failed");
        close(lb_sock);
        exit(EXIT_FAILURE);
    }

    // Listen for client connections
    if (listen(lb_sock, 5) < 0) {
        perror("Load balancer listen failed");
        close(lb_sock);
        exit(EXIT_FAILURE);
    }

    printf("Load Balancer is running on port %d...\n", LB_PORT);

    while (1) {
        // Accept client connection
        if ((client_sock = accept(lb_sock, (struct sockaddr*)&client_addr, &client_addr_len)) < 0) {
            perror("Client connection failed");
            continue;
        }

        // Receive data from client
        memset(buffer, 0, BUFFER_SIZE);
        recv(client_sock, buffer, BUFFER_SIZE, 0);

        printf("Received from client: %s\n", buffer);

        // Get CPU utilization of both servers
        int cpu_server1 = get_cpu_utilization(SERVER1_IP, SERVER1_PORT);
        int cpu_server2 = get_cpu_utilization(SERVER2_IP, SERVER2_PORT);

        printf("CPU Utilization - Server1: %d%%, Server2: %d%%\n", cpu_server1, cpu_server2);

        // Decide which server to use
        const char* selected_server_ip;
        int selected_server_port;
        if (cpu_server1 < cpu_server2) {
            selected_server_ip = SERVER1_IP;
            selected_server_port = SERVER1_PORT;
        } else {
            selected_server_ip = SERVER2_IP;
            selected_server_port = SERVER2_PORT;
        }

        printf("Forwarding to server: %s:%d\n", selected_server_ip, selected_server_port);

        // Communicate with the selected server
        memset(response, 0, BUFFER_SIZE);
        communicate_with_server(selected_server_ip, selected_server_port, buffer, response);

        // Send the response back to the client
        send(client_sock, response, strlen(response), 0);

        printf("Sent to client: %s\n", response);

        // Close client connection
        close(client_sock);
    }

    // Close load balancer socket
    close(lb_sock);

    return 0;
}
