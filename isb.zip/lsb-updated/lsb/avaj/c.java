import java.io.*;
import java.net.*;

public class c {
    public static void main(String[] args) {
        String hostname = "localhost";
        int port = 9000;

        try (Socket socket = new Socket(hostname, port)) {
            OutputStream output = socket.getOutputStream();
            PrintWriter writer = new PrintWriter(output, true);

            InputStream input = socket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));

            // Send strings to the server
            BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
            String text;

            System.out.println("Enter text (type 'exit' to quit):");
            while (true) {
                text = consoleReader.readLine();

                if (text.equalsIgnoreCase("exit")) {
                    break;
                }

                writer.println(text); // Send to server
                String response = reader.readLine(); // Receive from server
                System.out.println("Server responded: " + response);
            }
        } catch (UnknownHostException ex) {
            System.out.println("Server not found: " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("I/O error: " + ex.getMessage());
        }
    }
}
