#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>

#define PORT 9000
#define BUFFER_SIZE 1024
#define MAX_CLIENTS 100

typedef struct {
    int client_id;
    char ip_address[INET_ADDRSTRLEN];
    int port;
} ClientInfo;

ClientInfo master_table[MAX_CLIENTS];
int client_count = 0;
pthread_mutex_t table_lock;

// Function to update the master table
void update_master_table(int client_id, const char *ip_address, int port) {
    pthread_mutex_lock(&table_lock);
    master_table[client_count].client_id = client_id;
    strncpy(master_table[client_count].ip_address, ip_address, INET_ADDRSTRLEN);
    master_table[client_count].port = port;
    client_count++;
    pthread_mutex_unlock(&table_lock);
}

// Function to send the master table to the client
void send_master_table(int client_socket) {
    pthread_mutex_lock(&table_lock);
    send(client_socket, &client_count, sizeof(client_count), 0);
    send(client_socket, master_table, sizeof(master_table[0]) * client_count, 0);
    pthread_mutex_unlock(&table_lock);
}

// Thread function to handle each client
void *handle_client(void *arg) {
    int client_socket = *(int *)arg;
    free(arg);

    struct sockaddr_in client_addr;
    socklen_t addr_len = sizeof(client_addr);
    getpeername(client_socket, (struct sockaddr *)&client_addr, &addr_len);

    char ip_address[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &client_addr.sin_addr, ip_address, INET_ADDRSTRLEN);
    int client_port = ntohs(client_addr.sin_port);

    printf("New client connected: %s:%d\n", ip_address, client_port);

    // Update the master table
    update_master_table(client_socket, ip_address, client_port);

    // Send the updated master table to the client
    send_master_table(client_socket);

    close(client_socket);
    return NULL;
}

int main() {
    int server_socket, *client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);

    pthread_mutex_init(&table_lock, NULL);

    // Create the server socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Configure the server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind the socket to the port
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_socket, 5) < 0) {
        perror("Listen failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on port %d...\n", PORT);

    while (1) {
        // Accept a new client connection
        client_socket = malloc(sizeof(int));
        *client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_addr_len);
        if (*client_socket < 0) {
            perror("Client connection failed");
            free(client_socket);
            continue;
        }

        // Create a new thread to handle the client
        pthread_t thread;
        if (pthread_create(&thread, NULL, handle_client, client_socket) != 0) {
            perror("Thread creation failed");
            free(client_socket);
            continue;
        }

        pthread_detach(thread);
    }

    close(server_socket);
    pthread_mutex_destroy(&table_lock);

    return 0;
}


//gcc -o master_server master_server.c -lpthread
//gcc -o master_client master_client.c
