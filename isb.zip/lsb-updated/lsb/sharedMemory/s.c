#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>    // For O_CREAT, O_EXCL
#include <sys/mman.h> // For mmap, shm_open
#include <sys/stat.h> // For mode constants
#include <unistd.h>   // For ftruncate
#include <semaphore.h>

#define SHARED_MEM_NAME "/shared_mem_example"
#define SEMAPHORE_NAME "/semaphore_example"
#define SHARED_MEM_SIZE sizeof(int)

int main() {
    int shm_fd;               // Shared memory file descriptor
    int *shared_counter;      // Pointer to shared memory
    sem_t *sem;               // Semaphore
    int increment_times = 10; // Number of increments

    // Create and initialize shared memory
    shm_fd = shm_open(SHARED_MEM_NAME, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("Failed to create shared memory");
        exit(EXIT_FAILURE);
    }

    // Set the size of the shared memory
    if (ftruncate(shm_fd, SHARED_MEM_SIZE) == -1) {
        perror("Failed to set size of shared memory");
        exit(EXIT_FAILURE);
    }

    // Map shared memory to process address space
    shared_counter = mmap(0, SHARED_MEM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shared_counter == MAP_FAILED) {
        perror("Failed to map shared memory");
        exit(EXIT_FAILURE);
    }

    // Initialize the shared counter to 0
    *shared_counter = 0;

    // Create and initialize semaphore
    sem = sem_open(SEMAPHORE_NAME, O_CREAT, 0666, 1); // Initial value of semaphore is 1
    if (sem == SEM_FAILED) {
        perror("Failed to create semaphore");
        exit(EXIT_FAILURE);
    }

    printf("Server is running. Incrementing counter %d times...\n", increment_times);

    for (int i = 0; i < increment_times; i++) {
        // Wait (decrement) semaphore
        sem_wait(sem);

        // Critical section: increment shared counter
        (*shared_counter)++;
        printf("Counter incremented to: %d\n", *shared_counter);

        // Signal (increment) semaphore
        sem_post(sem);

        // Simulate some work
        sleep(1);
    }

    printf("Final counter value: %d\n", *shared_counter);

    // Clean up resources
    munmap(shared_counter, SHARED_MEM_SIZE);
    close(shm_fd);
    shm_unlink(SHARED_MEM_NAME); // Remove shared memory
    sem_close(sem);
    sem_unlink(SEMAPHORE_NAME);  // Remove semaphore

    return 0;
}



//gcc -o server_shared_memory server_shared_memory.c -lrt -pthread
//./server_shared_memory
