#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
#define close closesocket
#else
#include <unistd.h>
#include <arpa/inet.h>
#endif
#define PORT 8080
#define BUFFER_SIZE 1024
void send_file(FILE *file, int client_sock)
{
    char buffer[BUFFER_SIZE] = {0};
    while (fgets(buffer, BUFFER_SIZE, file) != NULL)
    {
        if (send(client_sock, buffer, strlen(buffer), 0) == -1)
        {
            perror("Error sending file.");
            exit(EXIT_FAILURE);
        }
        memset(buffer, 0, BUFFER_SIZE);
    }
}
int main()
{
#ifdef _WIN32
    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);
#endif
    int server_sock, client_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
    char *filename = "file_to_send.txt";
    FILE *file = fopen(filename, "r");
    if (!file)
    {
        perror("File not found.");
        exit(EXIT_FAILURE);
    } // Creating socket
    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock < 0)
    {
        perror("Socket creation error.");
        exit(EXIT_FAILURE);
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;
    // Bind socket to port
    if (bind(server_sock, (struct sockaddr *)&server_addr,
             sizeof(server_addr)) < 0)
    {
        perror("Bind failed.");
        close(server_sock);
        exit(EXIT_FAILURE);
    }
    // Listen for incoming connections
    if (listen(server_sock, 5) < 0)
    {
        perror("Listen error.");
        close(server_sock);
        exit(EXIT_FAILURE);
    }
    printf("Server is listening on port %d...\n", PORT);
    // Accept client connection
    client_sock = accept(server_sock, (struct sockaddr *)&client_addr,
                         &client_addr_len);
    if (client_sock < 0)
    {
        perror("Client connection error.");
        close(server_sock);
        exit(EXIT_FAILURE);
    }
    printf("Client connected. Sending file...\n");
    // Send file content
    send_file(file, client_sock);
    printf("File sent successfully.\n");
    // Cleanup
    fclose(file);
    close(client_sock);
    close(server_sock);
#ifdef _WIN32
    WSACleanup();
#endif
    return 0;
}
