#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
#define close closesocket
#else
#include <unistd.h>
#include <arpa/inet.h>
#endif
#define PORT 8080
#define BUFFER_SIZE 1024
int main()
{
#ifdef _WIN32
    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);
#endif
    int client_sock;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE] = {0};
    char *filename = "received_file.txt";
    FILE *file = fopen(filename, "w");
    if (!file)
    {
        perror("Error opening file.");
        exit(EXIT_FAILURE);
    }
    // Create socket
    client_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (client_sock < 0)
    {
        perror("Socket creation error.");
        exit(EXIT_FAILURE);
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    // Connect to server
    if (connect(client_sock, (struct sockaddr *)&server_addr,
                sizeof(server_addr)) < 0)
    {
        perror("Connection failed.");
        close(client_sock);
        exit(EXIT_FAILURE);
    }
    printf("Connected to server.\n");
    // Receive file content
    int bytes_received;
    while ((bytes_received = recv(client_sock, buffer, BUFFER_SIZE, 0)) > 0)
    {
        fwrite(buffer, sizeof(char), bytes_received, file);
        memset(buffer, 0, BUFFER_SIZE);
    }
    printf("File received successfully.\n"); // Cleanup
    fclose(file);
    close(client_sock);
#ifdef _WIN32
    WSACleanup();
#endif
    return 0;
}
